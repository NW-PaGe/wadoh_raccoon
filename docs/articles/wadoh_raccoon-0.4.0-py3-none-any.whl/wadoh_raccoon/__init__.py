def main() -> None:
    print("Hello from wadoh-raccoon!")
