import polars as pl
from thefuzz import fuzz
from pydantic import BaseModel
from wadoh_raccoon.utils import helpers


class DataFrameMatcherResults(BaseModel):
    exact_matched: pl.DataFrame | pl.LazyFrame
    fuzzy_matched: pl.DataFrame | pl.LazyFrame
    fuzzy_unmatched: pl.DataFrame | pl.LazyFrame
    no_demo: pl.DataFrame | pl.LazyFrame

    # Required when using polars dataframes
    model_config = {
        'arbitrary_types_allowed': True
    }


class DataFrameMatcher:
    """
    A utility class for matching records.

    This class provides functionality to match submissions to cases (epi 
    data) based on exact matching via accessions or fuzzy matching based on
    patient demographics

    Parameters
    -----------
    df_src: pl.DataFrame 
        Source dataframe containing any Key(s) and patient demographics.
    df_ref: pl.DataFrame 
        Reference queried dataframe containing patient demographics. 
    first_name: str | tuple[str, str]
        The first name demographic column name in the source and reference dataframes.
        If the names are different, they should be provided in a tuple containing the
        source name first, followed by the reference name.
    last_name: str | tuple[str, str]
        The last name demographic column name in the source and reference dataframes.
        If the names are different, they should be provided in a tuple containing the
        source name first, followed by the reference name.
    dob: str | tuple[str, str]
        The birth date demographic column name in the source and reference dataframes.
        If the names are different, they should be provided in a tuple containing the
        source name first, followed by the reference name.
    spec_col_date: str | tuple[str, str]
        The specimen collection date column name in the source and reference dataframes.
        If the names are different, they should be provided in a tuple containing the
        source name first, followed by the reference name.
    key: str | list (optional)
        The key (or list of keys) which group to a distinct source record. Only one match can be
        returned per distinct key. If no key given, each row in the source df will be treated as
        a distinct record to be matched.
    threshold: int | float (optional)
        The inclusive fuzzy scoring threshold used to filter fuzzy matches. Matches with a score 
        at or above the threshold will be returned in the fuzzy matched object. Defaults to 80.
    day_max: int (optional)
        The max number of days between reference and source specimen collection dates a fuzzy matched record
        can have and be returned as a match
    business_day_max: int (optional)
        The max number of business days between reference and source specimen collection dates a fuzzy matched
        record can have and be returned as a match. Business days are counted as weekdays (holidays are
        not accounted for).

    Returns
    -------
    fuzzy_matched_review: pl.DataFrame
        records that successfully fuzzy matched
    fuzzy_without_demo: pl.DataFrame
        records missing demographics and can't be matched
    fuzzy_matched_none: pl.DataFrame
        records that did not have any match
    fuzzy_matched_roster: pl.DataFrame
        records that had an exact match to reference dataframe

    Examples
    --------


    **Step 1:** Import the packages:
    ```{python}
    from wadoh_raccoon import dataframe_matcher as dfm
    import polars as pl
    from datetime import date

    ```

    **Step 2:** The fuzzy matching functions need two dataframes to match. Bring your dataframe and the reference dataframe:
    ```{python}
    # Create example data
    your_df = pl.DataFrame({
        'submission_number': [453278555, 453278555, 887730141],
        'first_name': ['DAVIS', 'DAVIS', 'GRANT'],
        'last_name': ['SMITHDAVIS', 'SMITHDAVIS', 'MITHCELL'],
        'sub_collection_date': [date(2024, 11, 29), date(2024, 11, 29), date(2024, 12, 2)],
        'birth_date': [date(1989, 7, 15), date(1989, 7, 15), date(1990, 6, 21)]
    })

    reference_df = pl.DataFrame({
        'CASE_ID': [100000032, 100000041, 100020000],
        'first_name_reference': ['DAVID', 'DAVID', 'TRASH'],
        'last_name_reference': ['SMITDAVIS', 'SMITDAVIS', 'PANDA'],
        'ref_collection_date': [date(2024, 11, 29), date(2024, 8, 31), date(2024, 8, 31)],
        'birth_date': [date(1989, 7, 15), date(1989, 7, 15), date(1990, 6, 21)]
    })
    ```

    **Step 3:** Initalize the fuzzy matching class and input which dataframes and columns you are matching on
    ```{python}
    fuzzy_init = dfm.DataFrameMatcher(
        df_src=your_df,
        df_ref=reference_df,
        first_name=('first_name', first_name_reference'),
        last_name=('last_name', 'last_name_reference'),
        dob='birth_date',
        spec_col_date=('sub_collection_date', 'ref_collection_date'),
        key='submission_number',
        threshold=80  # set what kind of fuzzy threshold you want, 100 being exact match
    )
    ```

    **Step 4:** Run fuzzy matching! This will output data on what matched and what didn't match.

    ```{python}
    #| class-output: box
    result = fuzzy_init.match()
    ```

    You can also examine the output dataframes by pulling them out of the result class, like this:


    ```python
    result.fuzzy_unmatched
    ```
    ```{python}
    #| echo: false
    from wadoh_raccoon.utils import helpers
    helpers.gt_style(df_inp=result.fuzzy_unmatched)
    ```

    ```python
    result.fuzzy_matched
    ```
    ```{python}
    #| echo: false
    from wadoh_raccoon.utils import helpers
    helpers.gt_style(df_inp=result.fuzzy_matched)
    ```
    <br>
    <br>
    <br>

    """

    def __init__(
        self, 
        df_src: pl.DataFrame, 
        df_ref: pl.DataFrame,
        first_name: str | tuple[str, str],
        last_name: str | tuple[str, str],
        dob: str | tuple[str, str],
        spec_col_date: str | tuple[str, str],
        key: str | list | None = None,
        threshold: int | float = 80,
        day_max: int | None = None,
        business_day_max: int | None = None
    ):

        # Source and reference data
        self.df_src = df_src
        self.df_ref = df_ref

        # Column names
        if isinstance(first_name, str):
            first_name = (first_name, first_name)
        self.first_name_src, self.first_name_ref = first_name

        if isinstance(last_name, str):
            last_name = (last_name, last_name)
        self.last_name_src, self.last_name_ref = last_name

        if isinstance(dob, str):
            dob = (dob, dob)
        self.dob_src, self.dob_ref = dob

        if isinstance(spec_col_date, str):
            spec_col_date = (spec_col_date, spec_col_date)
        self.spec_col_date_src, self.spec_col_date_ref = spec_col_date

        # submission key
        if key is None:
            self.key_isnone = True
            self.key = ['___key___']
            self.df_src = self.df_src.with_row_index(name=self.key[0])
        else:
            self.key_isnone = False
            if isinstance(key, str):
                key = [key]
            self.key = key
        
        # threshold
        self.threshold = threshold

        # day thresholds
        self.day_max = day_max
        self.business_day_max = business_day_max

    @staticmethod
    def __prep_df(df, first_name, last_name, spec_col_date, dob, output_spec_col_name, output_dob_name):

        clean_df = (
            df
            .with_columns(
                # clean_name converts the names to first_name_clean & last_name_clean
                helpers.clean_name(first_name).alias("first_name_clean"),
                helpers.clean_name(last_name).alias("last_name_clean"),
                temp_spec_col=helpers.date_format(df=df, col=spec_col_date),
                temp_dob_col=helpers.date_format(df=df, col=dob)
            )
            .rename({"temp_spec_col": output_spec_col_name, "temp_dob_col": output_dob_name})
        )

        return clean_df

    def clean_all(self) -> (pl.DataFrame, pl.DataFrame):

        ref_prep = (
            self.__prep_df(
                df=self.df_ref,
                first_name=self.first_name_ref,
                last_name=self.last_name_ref,
                spec_col_date=self.spec_col_date_ref,
                dob=self.dob_ref,
                output_spec_col_name='reference_collection_date',
                output_dob_name='reference_dob'
            )
            # Remove bad records
            .filter(
                (pl.col('first_name_clean').is_not_null()) &
                (pl.col('last_name_clean').is_not_null())
            )
        )

        submissions_to_fuzzy_prep = (
            self.__prep_df(
                df=self.df_src,
                first_name=self.first_name_src,
                last_name=self.last_name_src,
                spec_col_date=self.spec_col_date_src,
                dob=self.dob_src,
                output_spec_col_name='submitted_collection_date',
                output_dob_name='submitted_dob'
            )
        )

        return ref_prep, submissions_to_fuzzy_prep

    @staticmethod
    def filter_demo(submissions_to_fuzzy_prep) -> (pl.DataFrame, pl.DataFrame):

        # 2. Split by presence of demographics and specimen collection date
        fuzzy_with_demo = (
            submissions_to_fuzzy_prep
            .filter(pl.col('first_name_clean').is_not_null() & 
                    pl.col('last_name_clean').is_not_null() & 
                    pl.col('submitted_collection_date').is_not_null() &
                    pl.col('submitted_dob').is_not_null())
        )

        # save fuzzy without demographics
        fuzzy_without_demo = (
            submissions_to_fuzzy_prep
            .filter(pl.col('first_name_clean').is_null() |
                    pl.col('last_name_clean').is_null() | 
                    pl.col('submitted_collection_date').is_null() |
                    pl.col('submitted_dob').is_null())
        )

        return fuzzy_with_demo, fuzzy_without_demo


    def find_exact_match(self, ref_prep, fuzzy_with_demo) -> (pl.DataFrame, pl.DataFrame):

        indicator = '___indicator___'  # Name for temp indicator col to determine join outcome

        potential_matches = (
            fuzzy_with_demo
            .join(ref_prep.with_columns(pl.lit(True).alias(indicator)),  # Add indicator column to determine join
                left_on=['first_name_clean','last_name_clean','submitted_dob'],
                right_on=['first_name_clean','last_name_clean','reference_dob'],
                how="left",
                suffix="_em"
            )
            .with_columns(
                date_subtract = (pl.col('submitted_collection_date') - pl.col('reference_collection_date')).abs()
            )
            # for ones with multiple matches, pull the closest match based on collection date
            .sort(by=self.key+['date_subtract'], nulls_last=True)
            .unique(subset=self.key, keep='first')
        )

        exact_match = (
            potential_matches
            .filter(pl.col(indicator).is_not_null())  # Keep only fields with ref_prep joined
            .drop(indicator)  # Drop the temp indicator col
        )

        # Drop key if created during matching
        if self.key_isnone:
            exact_match = exact_match.drop(self.key)

        needs_fuzzy_match = (
            potential_matches
            .filter(pl.col(indicator).is_null())  # Keep only fields with ref_prep not joined
            .drop(indicator)  # Drop the temp indicator col
            .select(fuzzy_with_demo.collect_schema().names())  # Drop the previously joined null value cols
        )

        # block/join based on dob
        # for the remaining records that need to be fuzzy matched, 
        # find all the records in the reference df that match based on dob
        # this will give us a smaller pool to actually fuzzy match the names against,
        # as opposed to fuzzy matching one name vs thousands
        dob_match = (
            needs_fuzzy_match
            .join(
                ref_prep,
                left_on = 'submitted_dob',
                right_on='reference_dob',
                how = 'left'
            )
        )

        return exact_match, dob_match

    @staticmethod
    def score(df):
        return (
            df
            .with_columns(

                # First get the fuzz ratio with the first name
                pl.struct(['first_name_clean', 'first_name_clean_right'])
                .map_elements(
                    lambda cols: fuzz.ratio(cols['first_name_clean'], cols['first_name_clean_right']),
                    skip_nulls=False,
                    return_dtype=pl.Int64
                )
                .alias('first_name_result'),

                # Now get the fuzz ratio with the last name
                pl.struct(['last_name_clean', 'last_name_clean_right'])
                .map_elements(
                    lambda cols: fuzz.ratio(cols['last_name_clean'], cols['last_name_clean_right']),
                    skip_nulls=False,
                    return_dtype=pl.Int64
                )
                .alias('last_name_result'),

                # Now reverse - WDRS is known to switch first and last names
                # First get the fuzz ratio with the first name
                pl.struct(['first_name_clean', 'last_name_clean_right'])
                .map_elements(
                    lambda cols: fuzz.ratio(cols['first_name_clean'], cols['last_name_clean_right']),
                    skip_nulls=False,
                    return_dtype=pl.Int64
                )
                .alias('reverse_first_name_result'),

                # Now get the fuzz ratio with the last name
                pl.struct(['last_name_clean', 'first_name_clean_right'])
                .map_elements(
                    lambda cols: fuzz.ratio(cols['last_name_clean'], cols['first_name_clean_right']),
                    skip_nulls=False,
                    return_dtype=pl.Int64
                )
                .alias('reverse_last_name_result'),

            )
            .with_columns(
                # Now get the ratios between first and last name matches
                pl.mean_horizontal('first_name_result', 'last_name_result').alias('match_ratio'),
                pl.mean_horizontal('reverse_first_name_result', 'reverse_last_name_result').alias(
                    'reverse_match_ratio')
            )
        )

    def fuzzy_match(self, dob_match) -> (pl.DataFrame, pl.DataFrame):
        """ 

        Where the magic happens. Do the fuzzy matching to the dataframe

        Parameters
        ----------
        dob_match: pl.DataFrame
            the dataframe that has records grouped by their dob match
        
        Returns
        -------
        fuzzy_matched: pl.DataFrame
            dataframe with matches that met or exceeded the fuzzy matching score threshold
        fuzzy_unmatched: pl.DataFrame
            dataframe with matches that failed to meet the fuzzy matching score threshold
        
        Examples
        --------
        
        ```python
        from wadoh_raccoon import dataframe_matcher as dfm
        import polars as pl
        from datetime import date

        # Create example data
        df = pl.DataFrame({
            'submission_number': [453278555, 453278555, 887730141],
            'first_name_clean': ['DAVIS', 'DAVIS', 'GRANT'],
            'last_name_clean': ['SMITHDAVIS', 'SMITHDAVIS', 'MITHCELL'],
            'submitted_collection_date': [date(2024, 11, 29), date(2024, 11, 29), date(2024, 12, 2)],
            'submitted_dob': [date(1989, 7, 15), date(1989, 7, 15), date(1990, 6, 21)],
             'CASE_ID': [100000032, 100000041, None],
            'first_name_clean_right': ['DAVID', 'DAVID', None],
            'last_name_clean_right': ['SMITDAVIS', 'SMITDAVIS', None],
             'reference_collection_date': [date(2024, 11, 29), date(2024, 8, 31), None]
        })

        # Init dataframe matcher
        # (this is not how to use the instance but input data not used in this example)
        instance = dfm.DataFrameMatcher(df, df)
        fuzzy_matched, fuzzy_unmatched = instance.fuzzy_match(dob_match=df)
        ```
        
        Fuzzy match found:
        ```python
        helpers.gt_style(df_inp=fuzzy_matched)
        ```

        no matches found:
        ```python
        helpers.gt_style(df_inp=fuzzy_matched_none)
        ```

        """

        # ----- Init variables ----- #
        fuzzy_matched = pl.DataFrame()
        fuzzy_unmatched = pl.DataFrame()

        # ------- Fuzzy Matching ------- #

        if helpers.lazy_height(dob_match) > 0:
            multiple_matches_ratios = (
                self.score(dob_match.lazy())
                # Get a date range calculation of days between submitted collection date and ref collection date
                .with_columns(
                    day_count=
                    pl.col('reference_collection_date').sub(pl.col('submitted_collection_date')).dt.total_days().abs(),
                    business_day_count=
                    pl.business_day_count(start='submitted_collection_date', end='reference_collection_date').abs()
                )
            )

            # Get ones that matched on ratio >= threshold and pass day checks (if applicable)
            multiple_matches_ratios_final = multiple_matches_ratios.filter(
                pl.col('match_ratio').ge(self.threshold) | pl.col('reverse_match_ratio').ge(self.threshold)
            )

            if self.day_max:
                multiple_matches_ratios_final = multiple_matches_ratios_final.filter(
                    pl.col('day_count').le(self.day_max)
                )

            if self.business_day_max:
                multiple_matches_ratios_final = multiple_matches_ratios_final.filter(
                    pl.col('business_day_count').le(self.business_day_max)
                )

            # get the top matches of the groups with no score meeting the threshold
            fuzzy_unmatched = (
                multiple_matches_ratios
                # Remove any groups that had a match >= the threshold
                .join(multiple_matches_ratios_final, on=self.key, how='anti')
                # Get the max between the two ratio methods
                .with_columns(pl.max_horizontal('match_ratio', 'reverse_match_ratio').alias('max_ratio'))
                # Select the match with the highest ratio within each group
                .group_by(self.key)
                .agg(
                    pl.all()
                    .sort_by(['max_ratio', 'business_day_count', 'day_count'], descending=[True, False, False], nulls_last=True)
                    .first()
                )
                .drop('max_ratio', 'day_count', 'business_day_count')
            )

            # here we need to group by key and select row with the closest collection date difference
            fuzzy_matched = (
                multiple_matches_ratios_final
                .group_by(self.key)
                .agg(pl.all().sort_by(['business_day_count', 'day_count'], nulls_last=True).first())
            )

            if self.key_isnone:
                fuzzy_matched = fuzzy_matched.drop(self.key)
                fuzzy_unmatched = fuzzy_unmatched.drop(self.key)
                
            if isinstance(dob_match, pl.DataFrame):
                fuzzy_matched = fuzzy_matched.collect()
                fuzzy_unmatched = fuzzy_unmatched.collect()
                
        return fuzzy_matched, fuzzy_unmatched

    def __output_summary(
        self,
        fuzzy_matched_df,
        fuzzy_unmatched_df,
        fuzzy_without_demo_df,
        exact_match_df,
        submissions_to_fuzzy_df
    ):

        # First combine all outputs to check for any data leaks
        all_outputs = pl.concat([
                fuzzy_matched_df,
                fuzzy_unmatched_df,
                fuzzy_without_demo_df,
                exact_match_df
            ],
            # diagnonal_relaxed means that it will concat even if col types are different
            # it will convert the col types to be the same depending on the most frequent
            how = "diagonal_relaxed")

        # anti_join outputs to see if any data is missing from the outputs from the original df
        check_data_leaks = helpers.lazy_height(
            submissions_to_fuzzy_df.join(all_outputs, on=self.key, how="anti")
        )

        # try the opposite anti join
        check_data_leaks_reverse = helpers.lazy_height(
            all_outputs.join(submissions_to_fuzzy_df, on=self.key, how="anti")
        )

        # Output errors if any data leaks happen!
        if check_data_leaks > 0 or check_data_leaks_reverse > 0:
            print("ERROR!! Fuzzy data leaked. Data are in submissions_to_fuzzy_df that cannot be found in fuzzy outputs")
            print("Total processed: ",
                helpers.lazy_height(fuzzy_matched_df) +
                helpers.lazy_height(fuzzy_without_demo_df) +
                helpers.lazy_height(exact_match_df) +
                helpers.lazy_height(fuzzy_unmatched_df),
                "\nOriginal submissions to fuzzy (including no_match rematch attempt):",
                helpers.lazy_height(submissions_to_fuzzy_df)
            )
            raise pl.exceptions.PolarsError("ERROR!! Fuzzy data leaked. Data are in submissions_to_fuzzy_df that cannot be found in fuzzy outputs")
        else:
            print("Success: No data leaks detected. Insert victory cigar")

        # ------ Results ------ #
        em_height = helpers.lazy_height(exact_match_df)
        fm_height = helpers.lazy_height(fuzzy_matched_df)
        fum_height = helpers.lazy_height(fuzzy_unmatched_df)
        fwd_height = helpers.lazy_height(fuzzy_without_demo_df)

        print(em_height, "exact matches")
        print(fm_height, "fuzzy matched")
        print(fum_height, "no match found")
        print(fwd_height, "records without demo\n")
        

        print("Total unique persons processed: ",
            em_height + fm_height + fwd_height + fum_height,
            "\nOriginal submissions to fuzzy (including no_match rematch attempt):",
            helpers.lazy_height(submissions_to_fuzzy_df)
        )

    def match(self, verbose=True):
        
        # Process the Submissions to Fuzzy
        ref_prep, submissions_to_fuzzy_prep = self.clean_all()
        # Split by presence of demographics and specimen collection date
        fuzzy_with_demo, fuzzy_without_demo = self.filter_demo(submissions_to_fuzzy_prep)
        # find exact matches
        exact_matched, dob_match = self.find_exact_match(ref_prep, fuzzy_with_demo)
        # find fuzzy matches
        fuzzy_matched, fuzzy_unmatched = self.fuzzy_match(dob_match)
        # print summary
        if verbose:
            self.__output_summary(
                fuzzy_matched_df=fuzzy_matched, 
                fuzzy_unmatched_df=fuzzy_unmatched, 
                submissions_to_fuzzy_df=submissions_to_fuzzy_prep,
                fuzzy_without_demo_df=fuzzy_without_demo,
                exact_match_df=exact_matched
            )

        return DataFrameMatcherResults(
            exact_matched=exact_matched,
            fuzzy_matched=fuzzy_matched,
            fuzzy_unmatched=fuzzy_unmatched,
            no_demo=fuzzy_without_demo
        )
